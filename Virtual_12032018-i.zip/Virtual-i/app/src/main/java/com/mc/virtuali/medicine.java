package com.mc.virtuali;

/**
 * Created by SARTHIKA on 05-03-2018.
 */

public class medicine {

    String name=null;
    String dosage=null;
    String prescription=null;
    String intake=null;
}
